$(function(){
	
	$('.aside h4').click(function(){		
		
		$(this).siblings('ul').slideToggle();
	})
})
